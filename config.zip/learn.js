console.error("it's an error");
console.log("it's an error");
console.debug("it's an error");
console.warn("it's an error");
